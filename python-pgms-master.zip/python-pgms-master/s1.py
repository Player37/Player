#!/usr/bin/python3
name="dragonballsuper"
print(name)
print(name+"is an amazing anime ")
print(name*10)
print(name[1])
print(name[2])