a=[1,3,2,655,90]
print (a)
for i in a:
    if(i>10):
       print("greater than 10:")
       print(i)
    else:
        print("lesser tha 10 :")
        print(i)
        
       
