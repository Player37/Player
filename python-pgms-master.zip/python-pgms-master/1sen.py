g=int(input("enter ur grade:"))
print(g)
if g>100:
    print("grade should be less than 101...plz try again!!!")
elif g>=90:
    print("a")
elif g>=80:
    print("b")
elif g>=70:
    print("C")
elif g>=60:
    print("d")
elif g>=50:
    print("e")
else:
    print("F")
    
