n=input()
