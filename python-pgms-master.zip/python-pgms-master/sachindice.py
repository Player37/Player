#!/usr/bin/python3
# guess what this program does????
import random
r=random.randint(1,6) # gives random num on dice
print(r)
if r==6:
	print(r)
	print(": congatulations ")