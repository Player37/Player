a=[1,2,3,4,55,67,89]
b=[4,55,89,33,45,88]
for i in a:
    for j in b:
        if(i==j):
         print(a)
