#!/usr/bin/python3
a=4
print(6*a)
print(7-a)
print(a%2)		
print(a*8*8*8*8*8*8)