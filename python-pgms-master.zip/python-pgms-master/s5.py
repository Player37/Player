#!/usr/bin/python3
a=("flash")
b=("reverse")
c=a+b
print(c)
print(b+a)