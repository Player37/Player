#!/usr/bin/python
# guess what this program does ????
import random 
r=random.randint(345,999999) # gives random num
print(r)

