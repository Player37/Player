#!/usr/bin/python3
# guess what this program does ????
import random
r=random.randint(72,999) # gives random num
print(r)